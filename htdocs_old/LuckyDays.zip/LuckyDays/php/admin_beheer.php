<?php
session_start();
require_once '../config.php';

// Schakel foutmeldingen in voor debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Voeg een nieuwe gebruiker of admin toe
if (isset($_POST['add_user'])) {
    $new_username = $_POST['new_username'];
    $new_password = $_POST['new_password'];
    $role = $_POST['role'];

    // Hash het wachtwoord voor beveiliging
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

    // Controleer of de gebruikersnaam al bestaat
    $stmt = $conn->prepare("SELECT * FROM admins WHERE username = ?");
    if ($stmt === false) {
        die('Prepare-fout: ' . $conn->error);
    }

    $stmt->bind_param('s', $new_username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Gebruiker met deze gebruikersnaam bestaat al
        echo "Er bestaat al een gebruiker met deze naam.";
    } else {
        // Voeg de gebruiker/admin toe aan de database
        $stmt = $conn->prepare("INSERT INTO admins (username, password, role) VALUES (?, ?, ?)");
        if ($stmt === false) {
            die('Prepare-fout: ' . $conn->error);
        }

        $stmt->bind_param('sss', $new_username, $hashed_password, $role);

        // Controleer of de query succesvol was
        if ($stmt->execute()) {
            echo "Gebruiker succesvol toegevoegd!";
        } else {
            echo "Er ging iets mis bij het toevoegen van de gebruiker: " . $stmt->error;
        }
    }

    // Redirect terug naar gebruikersbeheerpagina
    header("Location: ../users.php");
    exit;
}

// Verwijder een gebruiker/admin
if (isset($_POST['delete_user'])) {
    $delete_id = $_POST['delete_user_id'];

    // Voorkom dat de ingelogde admin zichzelf verwijdert
    if ($_SESSION['username'] == $delete_id) {
        echo "Je kunt jezelf niet verwijderen!";
        header("Location: ../users.php");
        exit;
    }

    // Verwijder de gebruiker uit de database
    $stmt = $conn->prepare("DELETE FROM admins WHERE id = ?");
    if ($stmt === false) {
        die('Prepare-fout: ' . $conn->error);
    }

    $stmt->bind_param('i', $delete_id);
    if ($stmt->execute()) {
        echo "Gebruiker succesvol verwijderd!";
    } else {
        echo "Er ging iets mis bij het verwijderen van de gebruiker: " . $stmt->error;
    }

    // Redirect terug naar gebruikersbeheerpagina
    header("Location: ../users.php");
    exit;
}

// Wachtwoord wijzigen voor een gebruiker/admin
if (isset($_POST['edit_user'])) {
    $edit_id = $_POST['edit_user_id'];
    $new_password = $_POST['new_password']; // Het nieuwe wachtwoord van het formulier

    // Controleer of een nieuw wachtwoord is ingevoerd
    if (!empty($new_password)) {
        // Hash het nieuwe wachtwoord
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

        // Wachtwoord updaten in de database
        $stmt = $conn->prepare("UPDATE admins SET password = ? WHERE id = ?");
        if ($stmt === false) {
            die('Prepare-fout: ' . $conn->error);
        }

        $stmt->bind_param('si', $hashed_password, $edit_id);
        if ($stmt->execute()) {
            echo "Wachtwoord succesvol gewijzigd!";
        } else {
            echo "Er ging iets mis bij het wijzigen van het wachtwoord: " . $stmt->error;
        }
    } else {
        echo "Vul een nieuw wachtwoord in.";
    }

    // Redirect terug naar gebruikersbeheerpagina
    header("Location: ../users.php");
    exit;
}

?>