<?php
session_start();
require_once '../config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Zoek de gebruiker in de database
    $stmt = $conn->prepare('SELECT * FROM admins WHERE username = ?');
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $admin = $result->fetch_assoc();

    // Controleer of het wachtwoord klopt
    if ($admin && password_verify($password, $admin['password'])) {
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $username;
        header('Location: ../dashboard.php');
        exit;
    } else {
        echo "Ongeldige gebruikersnaam of wachtwoord.";
    }
}
?>