<?php
echo password_hash('94295899', PASSWORD_DEFAULT);
?>