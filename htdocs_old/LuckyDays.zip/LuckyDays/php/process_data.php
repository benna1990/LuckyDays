<?php
require_once 'config.php'; // Verbind met de database

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Haal de arrays met gegevens op uit het formulier
    $names = $_POST['name'];
    $dates = $_POST['date'];
    $bets = $_POST['bet'];
    $playedNumbers = $_POST['played'];

    // Loop door de arrays en sla elke rij op in de database
    for ($i = 0; $i < count($names); $i++) {
        $name = $names[$i];
        $date = $dates[$i];
        $bet = $bets[$i];
        $played = $playedNumbers[$i];

        // Sla de gegevens op in de database
        $stmt = $conn->prepare("INSERT INTO players (name, date, bet, played) VALUES (?, ?, ?, ?)");
        $stmt->bind_param('ssis', $name, $date, $bet, $played);
        $stmt->execute();
        $stmt->close();
    }

    // Redirect terug naar het dashboard
    header('Location: ../dashboard.php');
}
?>