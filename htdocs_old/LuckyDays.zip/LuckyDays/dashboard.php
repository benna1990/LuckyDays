<?php
session_start();
require_once 'config.php'; // Database verbinding

// Controleer of de gebruiker een beheerder is
$isAdmin = ($_SESSION['role'] === 'admin');

// Sla winnende nummers op in de sessie of haal ze uit de database
if (isset($_POST['set_winning_numbers'])) {
    $_SESSION['winning_numbers'] = array(
        $_POST['win_num1'], $_POST['win_num2'], $_POST['win_num3'],
        $_POST['win_num4'], $_POST['win_num5'], $_POST['win_num6'],
        $_POST['win_num7'], $_POST['win_num8'], $_POST['win_num9'], $_POST['win_num10']
    );
}

// Haal de winnende nummers van een externe bron (optioneel)
function fetchWinningNumbersFromWeb() {
    $url = "https://example.com/winning-numbers"; // Pas deze URL aan naar de juiste bron
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $output = curl_exec($ch);
    curl_close($ch);

    // Stel dat we de winnende nummers in JSON-formaat ontvangen
    $data = json_decode($output, true);
    return $data['winning_numbers'] ?? null;
}

// Haal de winnende nummers op via cURL (als er geen handmatig ingestelde nummers zijn)
if (!isset($_SESSION['winning_numbers'])) {
    $winning_numbers = fetchWinningNumbersFromWeb();
    $_SESSION['winning_numbers'] = $winning_numbers;
}

$winning_numbers = $_SESSION['winning_numbers'] ?? [];
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LuckyDays Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <script>
    // Functie voor AJAX-update van winnende nummers
    function updateWinningNumbers() {
        let formData = new FormData(document.getElementById('winningNumbersForm'));

        fetch('php/update_winning_numbers.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            document.getElementById('winningNumbersDisplay').innerHTML = data;
        })
        .catch(error => console.error('Error:', error));
    }

    // Functie om dynamisch een nieuwe rij met invoervelden toe te voegen
    function addRow() {
        let table = document.getElementById("dataTableBody");
        let row = document.createElement("tr");

        row.innerHTML = `
            <td><input type="text" name="name[]" class="form-control" required></td>
            <td><input type="date" name="date[]" class="form-control" required></td>
            <td><input type="number" name="bet[]" class="form-control" required></td>
            <td><input type="text" name="played[]" class="form-control" required></td>
            <td><button type="button" class="btn btn-danger" onclick="removeRow(this)">Verwijderen</button></td>
        `;

        table.appendChild(row);
    }

    // Functie om een rij te verwijderen
    function removeRow(button) {
        let row = button.parentNode.parentNode;
        row.parentNode.removeChild(row);
    }

    // Functie voor live filtering van de tabel
    function filterTable() {
        let input = document.getElementById("filterInput").value.toLowerCase();
        let table = document.getElementById("dataTable");
        let rows = table.getElementsByTagName("tr");

        for (let i = 1; i < rows.length; i++) {
            let cells = rows[i].getElementsByTagName("td");
            let match = false;

            // Controleer elke cel in de rij
            for (let j = 0; j < cells.length; j++) {
                if (cells[j].innerText.toLowerCase().includes(input)) {
                    match = true;
                    break;
                }
            }

            rows[i].style.display = match ? "" : "none";
        }
    }
    </script>
</head>
<body>
    <div class="container mt-5">
        <h1>Welkom op het Dashboard, <?php echo $_SESSION['username']; ?></h1>

        <!-- Beheerder: Formulier voor het toevoegen van nieuwe gegevens -->
        <?php if ($isAdmin): ?>
            <h2>Beheerder: Voeg Nummers Toe</h2>
            <form action="php/add_numbers.php" method="POST">
                <div class="mb-3">
                    <label for="new_numbers">Nieuwe Nummers (gescheiden door komma's):</label>
                    <input type="text" name="new_numbers" class="form-control" required placeholder="Bijv. 4,10,12,14">
                </div>
                <div class="mb-3">
                    <label for="date">Datum van de Trekking:</label>
                    <input type="date" name="date" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-success">Voeg Nummers Toe</button>
            </form>
        <?php endif; ?>

        <!-- Winnende nummers invoeren -->
        <h2>Winnende Nummers Invoeren</h2>
        <form id="winningNumbersForm" onsubmit="event.preventDefault(); updateWinningNumbers();">
            <div class="row">
                <?php for ($i = 1; $i <= 10; $i++): ?>
                    <div class="col">
                        <label for="win_num<?php echo $i; ?>">Nummer <?php echo $i; ?></label>
                        <input type="number" name="win_num<?php echo $i; ?>" class="form-control" required min="1" max="80">
                    </div>
                <?php endfor; ?>
            </div>
            <button type="submit" class="btn btn-primary mt-3">Winnende Nummers Instellen</button>
        </form>

        <!-- Weergave van winnende nummers -->
        <div id="winningNumbersDisplay" class="mt-4">
            <?php if (!empty($winning_numbers)): ?>
                <h3>Ingevoerde Winnende Nummers</h3>
                <p><?php echo implode(', ', $winning_numbers); ?></p>
            <?php else: ?>
                <p>Geen winnende nummers ingesteld.</p>
            <?php endif; ?>
        </div>

        <!-- Filteren op naam of datum -->
        <h2 class="mt-5">Filteren</h2>
        <input type="text" id="filterInput" class="form-control" onkeyup="filterTable()" placeholder="Filter op naam of datum">

        <!-- Tabel met spelersgegevens en resultaten -->
        <h3 class="mt-5">Spelersgegevens</h3>
        <table id="dataTable" class="table table-striped">
            <thead>
                <tr>
                    <th>Naam</th>
                    <th>Datum</th>
                    <th>Ingezet</th>
                    <th>Gespeeld</th>
                    <th>Actie</th>
                </tr>
            </thead>
            <tbody id="dataTableBody">
                <!-- Dynamisch toegevoegde rijen komen hier -->
            </tbody>
        </table>

        <!-- Knop om een nieuwe rij toe te voegen -->
        <button type="button" class="btn btn-primary" onclick="addRow()">Voeg een rij toe</button>

        <!-- Formulier voor het versturen van gegevens -->
        <form action="php/process_data.php" method="POST">
            <button type="submit" class="btn btn-success mt-3">Opslaan</button>
        </form>
    </div>
</body>
</html>